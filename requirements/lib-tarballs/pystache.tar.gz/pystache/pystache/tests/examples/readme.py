
"""
TODO: add a docstring.

"""

class SayHello(object):
    def to(self):
        return "Pizza"
